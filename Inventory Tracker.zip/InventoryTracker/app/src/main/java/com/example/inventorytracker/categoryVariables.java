package com.example.inventorytracker;


import androidx.appcompat.app.AppCompatActivity;

public class categoryVariables extends AppCompatActivity {
    String id;
    String category;
    String description;

    String titles;
}
