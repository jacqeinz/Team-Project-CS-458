package com.example.inventorytracker;


import androidx.appcompat.app.AppCompatActivity;

public class productview1 extends AppCompatActivity {
    String id;
    String product;
    String category;
    String supplier;
    String qty;
    String price;
    String total;
    String titles;



}
