package com.example.inventorytracker;

import androidx.appcompat.app.AppCompatActivity;

public class supplierVariables extends AppCompatActivity {
    String id;
    String supplier;
    String description;

    String titles;
}